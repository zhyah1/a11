"use client"; // Add this line at the top

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";  
import {Label}from "@/components/ui/label";  
import {Card, CardHeader, CardTitle, CardContent, CardFooter}from "@/components/ui/card";
import { useState } from "react";
import Link from 'next/link';

export default function Home() {
  const [email, setEmail] = useState("");

  const handleInputChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle the form submission logic here
    console.log("Email submitted:", email);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md p-6 bg-white rounded-lg shadow-lg">
        <CardHeader className="text-center">
          <img
            src="Rectangle.png"
            alt="Sociocademy Logo"
            className="mx-auto mb-6"
          />
          <CardTitle className="text-2xl font-bold mb-4">
            Revolutionize your remote Classrooms to a Smart Learning Space
          </CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <Label htmlFor="email" className="block text-sm font-medium">
              Enter your business email address to start with
            </Label>
            <Input
              type="email"
              id="email"
              value={email}
              onChange={handleInputChange}
              required
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </CardContent>
          <CardFooter className="mt-6 flex flex-col items-center">
            <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-md" ><Link href="\pages" passHref>
              Continue
              </Link> </Button>
            <p className="text-sm text-center mt-4 text-gray-500">
              By Continuing, You're Agreeing To Our Customer Terms Of Service, User Terms Of Service, Privacy Policy, And Cookie Policy.
            </p>
          </CardFooter>
        </form>
      </Card>
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex justify-center space-x-4 text-gray-500">
    <a href="#" className="hover:text-gray-900">Privacy & Terms</a>
    <a href="#" className="hover:text-gray-900">Contact Us</a>
    <a href="#" className="hover:text-gray-900">Change region</a>
</div>
      <div className="absolute bottom-8 right-8 flex space-x-4 text-gray-500">
        <a href="#" aria-label="Instagram">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            {/* Instagram SVG Path */}
          </svg>
        </a>
        <a href="#" aria-label="Twitter">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            {/* Twitter SVG Path */}
          </svg>
        </a>
        <a href="#" aria-label="Facebook">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            {/* Facebook SVG Path */}
          </svg>
        </a>
      </div>
    </div>
  );
}
